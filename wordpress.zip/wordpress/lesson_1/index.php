<?php get_header(); ?>

	<h1>This is my index</h1>

<?php get_footer(); ?>