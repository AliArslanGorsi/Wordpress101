	
	<footer>
		<p>This is my footer</p>
	</footer>
	
	</body>
</html>